public class masyvai02 {


    public static void main(String[] args) {

        int[] array = {1, 2, 3, 4, 5, 6};

        System.out.println(array[0]);
        System.out.println(array[5]);
        }
    }

