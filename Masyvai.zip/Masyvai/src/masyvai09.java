import java.util.Arrays;
import java.util.Scanner;

public class masyvai09 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int number = rd.nextInt();

        int [] array = new int [number];

        System.out.println("Iveskite intervalo pradzia:");
        int min = rd.nextInt();

        System.out.println("Iveskite intervalo pabaiga:");
        int max = rd.nextInt();

        for (int i = 0; i < array.length; i++) {
            array [i] = random (min, max);
        }

        System.out.print(Arrays.toString(array));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}