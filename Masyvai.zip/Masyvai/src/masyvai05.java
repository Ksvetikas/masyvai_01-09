import java.util.Scanner;

public class masyvai05 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);
        System.out.println("Kiek padidinti? ");
        int number = rd.nextInt();

        int[] array = {99, 55, 77, 11, 22, 33, 44, 66, 88, 10, 12, 13, 14, 15, 16};

        System.out.println("Jeigu ivestas dydis =" + number + " , tai skaiciu reiksmes:" );

        for (int i = 0; i < array.length; i++) {
            System.out.print(array [i] + number + ", ");
        }

        rd.close();
    }

}