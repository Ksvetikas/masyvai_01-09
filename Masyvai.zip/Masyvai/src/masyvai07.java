import java.util.Scanner;

public class masyvai07 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        int [] arr1 = new int [6];

        System.out.println("Iveskite pirmojo masyvo skaiciu reiksmes:");

        for (int i = 0; i < arr1.length; i++) {
            System.out.println("Kokia skaiciaus reiksme? ");
            int number = rd.nextInt();
            arr1 [i] = number;
        }

        int [] arr2 = new int [6];

        System.out.println("Iveskite antrojo masyvo skaiciu reiksmes:");

        for (int i = 0; i < arr2.length; i++) {
            System.out.println("Kokia skaiciaus reiksme? ");
            int number = rd.nextInt();
            arr2 [i] = number;
        }

        for (int i = 0; i < arr1.length; i++) {
            System.out.print(arr1 [i] + arr2 [i] + ", ");
        }

        rd.close();
    }

}